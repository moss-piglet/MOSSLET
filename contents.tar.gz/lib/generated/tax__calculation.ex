defmodule Stripe.Tax.Calculation do
  use Stripe.Entity

  @moduledoc "A Tax Calculation allows you to calculate the tax to collect from your customer.\n\nRelated guide: [Calculate tax in your custom payment flow](https://stripe.com/docs/tax/custom)"
  (
    defstruct [
      :amount_total,
      :currency,
      :customer,
      :customer_details,
      :expires_at,
      :id,
      :line_items,
      :livemode,
      :object,
      :ship_from_details,
      :shipping_cost,
      :tax_amount_exclusive,
      :tax_amount_inclusive,
      :tax_breakdown,
      :tax_date
    ]

    @typedoc "The `tax.calculation` type.\n\n  * `amount_total` Total amount after taxes in the [smallest currency unit](https://stripe.com/docs/currencies#zero-decimal).\n  * `currency` Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).\n  * `customer` The ID of an existing [Customer](https://stripe.com/docs/api/customers/object) used for the resource.\n  * `customer_details` \n  * `expires_at` Timestamp of date at which the tax calculation will expire.\n  * `id` Unique identifier for the calculation.\n  * `line_items` The list of items the customer is purchasing.\n  * `livemode` Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode.\n  * `object` String representing the object's type. Objects of the same type share the same value.\n  * `ship_from_details` The details of the ship from location, such as the address.\n  * `shipping_cost` The shipping cost details for the calculation.\n  * `tax_amount_exclusive` The amount of tax to be collected on top of the line item prices.\n  * `tax_amount_inclusive` The amount of tax already included in the line item prices.\n  * `tax_breakdown` Breakdown of individual tax amounts that add up to the total.\n  * `tax_date` Timestamp of date at which the tax rules and rates in effect applies for the calculation.\n"
    @type t :: %__MODULE__{
            amount_total: integer,
            currency: binary,
            customer: binary | nil,
            customer_details: term,
            expires_at: integer | nil,
            id: binary | nil,
            line_items: term | nil,
            livemode: boolean,
            object: binary,
            ship_from_details: term | nil,
            shipping_cost: term | nil,
            tax_amount_exclusive: integer,
            tax_amount_inclusive: integer,
            tax_breakdown: term,
            tax_date: integer
          }
  )

  (
    @typedoc "The address from which the goods are being shipped from."
    @type address :: %{
            optional(:city) => binary | binary,
            optional(:country) => binary,
            optional(:line1) => binary | binary,
            optional(:line2) => binary | binary,
            optional(:postal_code) => binary | binary,
            optional(:state) => binary | binary
          }
  )

  (
    @typedoc "Details about the customer, including address and tax IDs."
    @type customer_details :: %{
            optional(:address) => address,
            optional(:address_source) => :billing | :shipping,
            optional(:ip_address) => binary,
            optional(:tax_ids) => list(tax_ids),
            optional(:taxability_override) => :customer_exempt | :none | :reverse_charge
          }
  )

  (
    @typedoc nil
    @type line_items :: %{
            optional(:amount) => integer,
            optional(:metadata) => %{optional(binary) => binary},
            optional(:product) => binary,
            optional(:quantity) => integer,
            optional(:reference) => binary,
            optional(:tax_behavior) => :exclusive | :inclusive,
            optional(:tax_code) => binary
          }
  )

  (
    @typedoc "Details about the address from which the goods are being shipped."
    @type ship_from_details :: %{optional(:address) => address}
  )

  (
    @typedoc "Shipping cost details to be used for the calculation."
    @type shipping_cost :: %{
            optional(:amount) => integer,
            optional(:shipping_rate) => binary,
            optional(:tax_behavior) => :exclusive | :inclusive,
            optional(:tax_code) => binary
          }
  )

  (
    @typedoc nil
    @type tax_ids :: %{
            optional(:type) =>
              :ad_nrt
              | :ae_trn
              | :al_tin
              | :am_tin
              | :ao_tin
              | :ar_cuit
              | :au_abn
              | :au_arn
              | :aw_tin
              | :az_tin
              | :ba_tin
              | :bb_tin
              | :bd_bin
              | :bf_ifu
              | :bg_uic
              | :bh_vat
              | :bj_ifu
              | :bo_tin
              | :br_cnpj
              | :br_cpf
              | :bs_tin
              | :by_tin
              | :ca_bn
              | :ca_gst_hst
              | :ca_pst_bc
              | :ca_pst_mb
              | :ca_pst_sk
              | :ca_qst
              | :cd_nif
              | :ch_uid
              | :ch_vat
              | :cl_tin
              | :cm_niu
              | :cn_tin
              | :co_nit
              | :cr_tin
              | :cv_nif
              | :de_stn
              | :do_rcn
              | :ec_ruc
              | :eg_tin
              | :es_cif
              | :et_tin
              | :eu_oss_vat
              | :eu_vat
              | :gb_vat
              | :ge_vat
              | :gn_nif
              | :hk_br
              | :hr_oib
              | :hu_tin
              | :id_npwp
              | :il_vat
              | :in_gst
              | :is_vat
              | :jp_cn
              | :jp_rn
              | :jp_trn
              | :ke_pin
              | :kg_tin
              | :kh_tin
              | :kr_brn
              | :kz_bin
              | :la_tin
              | :li_uid
              | :li_vat
              | :ma_vat
              | :md_vat
              | :me_pib
              | :mk_vat
              | :mr_nif
              | :mx_rfc
              | :my_frp
              | :my_itn
              | :my_sst
              | :ng_tin
              | :no_vat
              | :no_voec
              | :np_pan
              | :nz_gst
              | :om_vat
              | :pe_ruc
              | :ph_tin
              | :ro_tin
              | :rs_pib
              | :ru_inn
              | :ru_kpp
              | :sa_vat
              | :sg_gst
              | :sg_uen
              | :si_tin
              | :sn_ninea
              | :sr_fin
              | :sv_nit
              | :th_vat
              | :tj_tin
              | :tr_tin
              | :tw_vat
              | :tz_vat
              | :ua_vat
              | :ug_tin
              | :us_ein
              | :uy_ruc
              | :uz_tin
              | :uz_vat
              | :ve_rif
              | :vn_tin
              | :za_vat
              | :zm_tin
              | :zw_tin,
            optional(:value) => binary
          }
  )

  (
    nil

    @doc "<p>Retrieves a Tax <code>Calculation</code> object, if the calculation hasn’t expired.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/tax/calculations/{calculation}`\n"
    (
      @spec retrieve(
              calculation :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.Tax.Calculation.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def retrieve(calculation, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/tax/calculations/{calculation}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "calculation",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "calculation",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [calculation]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Retrieves the line items of a tax calculation as a collection, if the calculation hasn’t expired.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/tax/calculations/{calculation}/line_items`\n"
    (
      @spec list_line_items(
              calculation :: binary(),
              params :: %{
                optional(:ending_before) => binary,
                optional(:expand) => list(binary),
                optional(:limit) => integer,
                optional(:starting_after) => binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.List.t(Stripe.Tax.CalculationLineItem.t())}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def list_line_items(calculation, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/tax/calculations/{calculation}/line_items",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "calculation",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "calculation",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [calculation]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Calculates tax based on the input and returns a Tax <code>Calculation</code> object.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/tax/calculations`\n"
    (
      @spec create(
              params :: %{
                optional(:currency) => binary,
                optional(:customer) => binary,
                optional(:customer_details) => customer_details,
                optional(:expand) => list(binary),
                optional(:line_items) => list(line_items),
                optional(:ship_from_details) => ship_from_details,
                optional(:shipping_cost) => shipping_cost,
                optional(:tax_date) => integer
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.Tax.Calculation.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def create(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/tax/calculations", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )
end