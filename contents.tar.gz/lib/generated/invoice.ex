defmodule Stripe.Invoice do
  use Stripe.Entity

  @moduledoc "Invoices are statements of amounts owed by a customer, and are either\ngenerated one-off, or generated periodically from a subscription.\n\nThey contain [invoice items](https://stripe.com/docs/api#invoiceitems), and proration adjustments\nthat may be caused by subscription upgrades/downgrades (if necessary).\n\nIf your invoice is configured to be billed through automatic charges,\nStripe automatically finalizes your invoice and attempts payment. Note\nthat finalizing the invoice,\n[when automatic](https://stripe.com/docs/invoicing/integration/automatic-advancement-collection), does\nnot happen immediately as the invoice is created. Stripe waits\nuntil one hour after the last webhook was successfully sent (or the last\nwebhook timed out after failing). If you (and the platforms you may have\nconnected to) have no webhooks configured, Stripe waits one hour after\ncreation to finalize the invoice.\n\nIf your invoice is configured to be billed by sending an email, then based on your\n[email settings](https://dashboard.stripe.com/account/billing/automatic),\nStripe will email the invoice to your customer and await payment. These\nemails can contain a link to a hosted page to pay the invoice.\n\nStripe applies any customer credit on the account before determining the\namount due for the invoice (i.e., the amount that will be actually\ncharged). If the amount due for the invoice is less than Stripe's [minimum allowed charge\nper currency](/docs/currencies#minimum-and-maximum-charge-amounts), the\ninvoice is automatically marked paid, and we add the amount due to the\ncustomer's credit balance which is applied to the next invoice.\n\nMore details on the customer's credit balance are\n[here](https://stripe.com/docs/billing/customer/balance).\n\nRelated guide: [Send invoices to customers](https://stripe.com/docs/billing/invoices/sending)"
  (
    defstruct [
      :customer_address,
      :customer_tax_exempt,
      :last_finalization_error,
      :webhooks_delivered_at,
      :attempt_count,
      :customer_name,
      :shipping_cost,
      :invoice_pdf,
      :livemode,
      :customer,
      :statement_descriptor,
      :amount_shipping,
      :collection_method,
      :post_payment_credit_notes_amount,
      :auto_advance,
      :account_tax_ids,
      :created,
      :confirmation_secret,
      :subtotal_excluding_tax,
      :effective_at,
      :rendering,
      :application,
      :account_name,
      :pre_payment_credit_notes_amount,
      :status,
      :customer_phone,
      :description,
      :id,
      :period_end,
      :footer,
      :due_date,
      :status_transitions,
      :subtotal,
      :number,
      :default_tax_rates,
      :total_discount_amounts,
      :automatic_tax,
      :issuer,
      :customer_tax_ids,
      :latest_revision,
      :threshold_reason,
      :payments,
      :billing_reason,
      :total_pretax_credit_amounts,
      :currency,
      :ending_balance,
      :default_source,
      :amount_paid,
      :object,
      :amount_overpaid,
      :on_behalf_of,
      :period_start,
      :attempted,
      :discounts,
      :shipping_details,
      :lines,
      :customer_shipping,
      :customer_email,
      :total_excluding_tax,
      :from_invoice,
      :account_country,
      :hosted_invoice_url,
      :total,
      :subscription,
      :next_payment_attempt,
      :receipt_number,
      :test_clock,
      :starting_balance,
      :default_payment_method,
      :amount_remaining,
      :parent,
      :payment_settings,
      :automatically_finalizes_at,
      :custom_fields,
      :metadata,
      :amount_due,
      :total_taxes
    ]

    @typedoc "The `invoice` type.\n\n  * `account_country` The country of the business associated with this invoice, most often the business creating the invoice.\n  * `account_name` The public name of the business associated with this invoice, most often the business creating the invoice.\n  * `account_tax_ids` The account tax IDs associated with the invoice. Only editable when the invoice is a draft.\n  * `amount_due` Final amount due at this time for this invoice. If the invoice's total is smaller than the minimum charge amount, for example, or if there is account credit that can be applied to the invoice, the `amount_due` may be 0. If there is a positive `starting_balance` for the invoice (the customer owes money), the `amount_due` will also take that into account. The charge that gets generated for the invoice will be for the amount specified in `amount_due`.\n  * `amount_overpaid` Amount that was overpaid on the invoice. The amount overpaid is credited to the customer's credit balance.\n  * `amount_paid` The amount, in cents (or local equivalent), that was paid.\n  * `amount_remaining` The difference between amount_due and amount_paid, in cents (or local equivalent).\n  * `amount_shipping` This is the sum of all the shipping amounts.\n  * `application` ID of the Connect Application that created the invoice.\n  * `attempt_count` Number of payment attempts made for this invoice, from the perspective of the payment retry schedule. Any payment attempt counts as the first attempt, and subsequently only automatic retries increment the attempt count. In other words, manual payment attempts after the first attempt do not affect the retry schedule. If a failure is returned with a non-retryable return code, the invoice can no longer be retried unless a new payment method is obtained. Retries will continue to be scheduled, and attempt_count will continue to increment, but retries will only be executed if a new payment method is obtained.\n  * `attempted` Whether an attempt has been made to pay the invoice. An invoice is not attempted until 1 hour after the `invoice.created` webhook, for example, so you might not want to display that invoice as unpaid to your users.\n  * `auto_advance` Controls whether Stripe performs [automatic collection](https://stripe.com/docs/invoicing/integration/automatic-advancement-collection) of the invoice. If `false`, the invoice's state doesn't automatically advance without an explicit action.\n  * `automatic_tax` \n  * `automatically_finalizes_at` The time when this invoice is currently scheduled to be automatically finalized. The field will be `null` if the invoice is not scheduled to finalize in the future. If the invoice is not in the draft state, this field will always be `null` - see `finalized_at` for the time when an already-finalized invoice was finalized.\n  * `billing_reason` Indicates the reason why the invoice was created.\n\n* `manual`: Unrelated to a subscription, for example, created via the invoice editor.\n* `subscription`: No longer in use. Applies to subscriptions from before May 2018 where no distinction was made between updates, cycles, and thresholds.\n* `subscription_create`: A new subscription was created.\n* `subscription_cycle`: A subscription advanced into a new period.\n* `subscription_threshold`: A subscription reached a billing threshold.\n* `subscription_update`: A subscription was updated.\n* `upcoming`: Reserved for upcoming invoices created through the Create Preview Invoice API or when an `invoice.upcoming` event is generated for an upcoming invoice on a subscription.\n  * `collection_method` Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this invoice using the default source attached to the customer. When sending an invoice, Stripe will email this invoice to the customer with payment instructions.\n  * `confirmation_secret` The confirmation secret associated with this invoice. Currently, this contains the client_secret of the PaymentIntent that Stripe creates during invoice finalization.\n  * `created` Time at which the object was created. Measured in seconds since the Unix epoch.\n  * `currency` Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).\n  * `custom_fields` Custom fields displayed on the invoice.\n  * `customer` The ID of the customer who will be billed.\n  * `customer_address` The customer's address. Until the invoice is finalized, this field will equal `customer.address`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_email` The customer's email. Until the invoice is finalized, this field will equal `customer.email`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_name` The customer's name. Until the invoice is finalized, this field will equal `customer.name`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_phone` The customer's phone number. Until the invoice is finalized, this field will equal `customer.phone`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_shipping` The customer's shipping information. Until the invoice is finalized, this field will equal `customer.shipping`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_tax_exempt` The customer's tax exempt status. Until the invoice is finalized, this field will equal `customer.tax_exempt`. Once the invoice is finalized, this field will no longer be updated.\n  * `customer_tax_ids` The customer's tax IDs. Until the invoice is finalized, this field will contain the same tax IDs as `customer.tax_ids`. Once the invoice is finalized, this field will no longer be updated.\n  * `default_payment_method` ID of the default payment method for the invoice. It must belong to the customer associated with the invoice. If not set, defaults to the subscription's default payment method, if any, or to the default payment method in the customer's invoice settings.\n  * `default_source` ID of the default payment source for the invoice. It must belong to the customer associated with the invoice and be in a chargeable state. If not set, defaults to the subscription's default source, if any, or to the customer's default source.\n  * `default_tax_rates` The tax rates applied to this invoice, if any.\n  * `description` An arbitrary string attached to the object. Often useful for displaying to users. Referenced as 'memo' in the Dashboard.\n  * `discounts` The discounts applied to the invoice. Line item discounts are applied before invoice discounts. Use `expand[]=discounts` to expand each discount.\n  * `due_date` The date on which payment for this invoice is due. This value will be `null` for invoices where `collection_method=charge_automatically`.\n  * `effective_at` The date when this invoice is in effect. Same as `finalized_at` unless overwritten. When defined, this value replaces the system-generated 'Date of issue' printed on the invoice PDF and receipt.\n  * `ending_balance` Ending customer balance after the invoice is finalized. Invoices are finalized approximately an hour after successful webhook delivery or when payment collection is attempted for the invoice. If the invoice has not been finalized yet, this will be null.\n  * `footer` Footer displayed on the invoice.\n  * `from_invoice` Details of the invoice that was cloned. See the [revision documentation](https://stripe.com/docs/invoicing/invoice-revisions) for more details.\n  * `hosted_invoice_url` The URL for the hosted invoice page, which allows customers to view and pay an invoice. If the invoice has not been finalized yet, this will be null.\n  * `id` Unique identifier for the object. For preview invoices created using the [create preview](https://stripe.com/docs/api/invoices/create_preview) endpoint, this id will be prefixed with `upcoming_in`.\n  * `invoice_pdf` The link to download the PDF for the invoice. If the invoice has not been finalized yet, this will be null.\n  * `issuer` \n  * `last_finalization_error` The error encountered during the previous attempt to finalize the invoice. This field is cleared when the invoice is successfully finalized.\n  * `latest_revision` The ID of the most recent non-draft revision of this invoice\n  * `lines` The individual line items that make up the invoice. `lines` is sorted as follows: (1) pending invoice items (including prorations) in reverse chronological order, (2) subscription items in reverse chronological order, and (3) invoice items added after invoice creation in chronological order.\n  * `livemode` Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode.\n  * `metadata` Set of [key-value pairs](https://stripe.com/docs/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.\n  * `next_payment_attempt` The time at which payment will next be attempted. This value will be `null` for invoices where `collection_method=send_invoice`.\n  * `number` A unique, identifying string that appears on emails sent to the customer for this invoice. This starts with the customer's unique invoice_prefix if it is specified.\n  * `object` String representing the object's type. Objects of the same type share the same value.\n  * `on_behalf_of` The account (if any) for which the funds of the invoice payment are intended. If set, the invoice will be presented with the branding and support information of the specified account. See the [Invoices with Connect](https://stripe.com/docs/billing/invoices/connect) documentation for details.\n  * `parent` The parent that generated this invoice\n  * `payment_settings` \n  * `payments` Payments for this invoice\n  * `period_end` End of the usage period during which invoice items were added to this invoice. This looks back one period for a subscription invoice. Use the [line item period](/api/invoices/line_item#invoice_line_item_object-period) to get the service period for each price.\n  * `period_start` Start of the usage period during which invoice items were added to this invoice. This looks back one period for a subscription invoice. Use the [line item period](/api/invoices/line_item#invoice_line_item_object-period) to get the service period for each price.\n  * `post_payment_credit_notes_amount` Total amount of all post-payment credit notes issued for this invoice.\n  * `pre_payment_credit_notes_amount` Total amount of all pre-payment credit notes issued for this invoice.\n  * `receipt_number` This is the transaction number that appears on email receipts sent for this invoice.\n  * `rendering` The rendering-related settings that control how the invoice is displayed on customer-facing surfaces such as PDF and Hosted Invoice Page.\n  * `shipping_cost` The details of the cost of shipping, including the ShippingRate applied on the invoice.\n  * `shipping_details` Shipping details for the invoice. The Invoice PDF will use the `shipping_details` value if it is set, otherwise the PDF will render the shipping address from the customer.\n  * `starting_balance` Starting customer balance before the invoice is finalized. If the invoice has not been finalized yet, this will be the current customer balance. For revision invoices, this also includes any customer balance that was applied to the original invoice.\n  * `statement_descriptor` Extra information about an invoice for the customer's credit card statement.\n  * `status` The status of the invoice, one of `draft`, `open`, `paid`, `uncollectible`, or `void`. [Learn more](https://stripe.com/docs/billing/invoices/workflow#workflow-overview)\n  * `status_transitions` \n  * `subscription` \n  * `subtotal` Total of all subscriptions, invoice items, and prorations on the invoice before any invoice level discount or exclusive tax is applied. Item discounts are already incorporated\n  * `subtotal_excluding_tax` The integer amount in cents (or local equivalent) representing the subtotal of the invoice before any invoice level discount or tax is applied. Item discounts are already incorporated\n  * `test_clock` ID of the test clock this invoice belongs to.\n  * `threshold_reason` \n  * `total` Total after discounts and taxes.\n  * `total_discount_amounts` The aggregate amounts calculated per discount across all line items.\n  * `total_excluding_tax` The integer amount in cents (or local equivalent) representing the total amount of the invoice including all discounts but excluding all tax.\n  * `total_pretax_credit_amounts` Contains pretax credit amounts (ex: discount, credit grants, etc) that apply to this invoice. This is a combined list of total_pretax_credit_amounts across all invoice line items.\n  * `total_taxes` The aggregate tax information of all line items.\n  * `webhooks_delivered_at` Invoices are automatically paid or sent 1 hour after webhooks are delivered, or until all webhook delivery attempts have [been exhausted](https://stripe.com/docs/billing/webhooks#understand). This field tracks the time when webhooks for this invoice were successfully delivered. If the invoice had no webhooks to deliver, this will be set while the invoice is being created.\n"
    @type t :: %__MODULE__{
            account_country: binary | nil,
            account_name: binary | nil,
            account_tax_ids: term | nil,
            amount_due: integer,
            amount_overpaid: integer,
            amount_paid: integer,
            amount_remaining: integer,
            amount_shipping: integer,
            application: (binary | term | term) | nil,
            attempt_count: integer,
            attempted: boolean,
            auto_advance: boolean,
            automatic_tax: term,
            automatically_finalizes_at: integer | nil,
            billing_reason: binary | nil,
            collection_method: binary,
            confirmation_secret: term | nil,
            created: integer,
            currency: binary,
            custom_fields: term | nil,
            customer: (binary | Stripe.Customer.t() | Stripe.DeletedCustomer.t()) | nil,
            customer_address: term | nil,
            customer_email: binary | nil,
            customer_name: binary | nil,
            customer_phone: binary | nil,
            customer_shipping: term | nil,
            customer_tax_exempt: binary | nil,
            customer_tax_ids: term | nil,
            default_payment_method: (binary | Stripe.PaymentMethod.t()) | nil,
            default_source: (binary | Stripe.PaymentSource.t()) | nil,
            default_tax_rates: term,
            description: binary | nil,
            discounts: term,
            due_date: integer | nil,
            effective_at: integer | nil,
            ending_balance: integer | nil,
            footer: binary | nil,
            from_invoice: term | nil,
            hosted_invoice_url: binary | nil,
            id: binary,
            invoice_pdf: binary | nil,
            issuer: term,
            last_finalization_error: Stripe.ApiErrors.t() | nil,
            latest_revision: (binary | Stripe.Invoice.t()) | nil,
            lines: term,
            livemode: boolean,
            metadata: term | nil,
            next_payment_attempt: integer | nil,
            number: binary | nil,
            object: binary,
            on_behalf_of: (binary | Stripe.Account.t()) | nil,
            parent: term | nil,
            payment_settings: term,
            payments: term,
            period_end: integer,
            period_start: integer,
            post_payment_credit_notes_amount: integer,
            pre_payment_credit_notes_amount: integer,
            receipt_number: binary | nil,
            rendering: term | nil,
            shipping_cost: term | nil,
            shipping_details: term | nil,
            starting_balance: integer,
            statement_descriptor: binary | nil,
            status: binary | nil,
            status_transitions: term,
            subscription: (binary | Stripe.Subscription.t()) | nil,
            subtotal: integer,
            subtotal_excluding_tax: integer | nil,
            test_clock: (binary | Stripe.TestHelpers.TestClock.t()) | nil,
            threshold_reason: term,
            total: integer,
            total_discount_amounts: term | nil,
            total_excluding_tax: integer | nil,
            total_pretax_credit_amounts: term | nil,
            total_taxes: term | nil,
            webhooks_delivered_at: integer | nil
          }
  )

  (
    @typedoc nil
    @type acss_debit :: %{
            optional(:mandate_options) => mandate_options,
            optional(:verification_method) => :automatic | :instant | :microdeposits
          }
  )

  (
    @typedoc nil
    @type add_invoice_items :: %{
            optional(:discounts) => list(discounts),
            optional(:metadata) => %{optional(binary) => binary},
            optional(:period) => period,
            optional(:price) => binary,
            optional(:price_data) => price_data,
            optional(:quantity) => integer,
            optional(:tax_rates) => list(binary) | binary
          }
  )

  (
    @typedoc "Shipping address"
    @type address :: %{
            optional(:city) => binary,
            optional(:country) => binary,
            optional(:line1) => binary,
            optional(:line2) => binary,
            optional(:postal_code) => binary,
            optional(:state) => binary
          }
  )

  (
    @typedoc "Settings for automatic tax lookup for this invoice."
    @type automatic_tax :: %{optional(:enabled) => boolean, optional(:liability) => liability}
  )

  (
    @typedoc nil
    @type bancontact :: %{optional(:preferred_language) => :de | :en | :fr | :nl}
  )

  (
    @typedoc "Configuration for the bank transfer funding type, if the `funding_type` is set to `bank_transfer`."
    @type bank_transfer :: %{
            optional(:eu_bank_transfer) => eu_bank_transfer,
            optional(:type) => binary
          }
  )

  (
    @typedoc "Controls how prorations and invoices for subscriptions are calculated and orchestrated."
    @type billing_mode :: %{
            optional(:flexible) => flexible,
            optional(:type) => :classic | :flexible
          }
  )

  (
    @typedoc nil
    @type billing_thresholds :: %{optional(:usage_gte) => integer}
  )

  (
    @typedoc nil
    @type card :: %{
            optional(:installments) => installments,
            optional(:request_three_d_secure) => :any | :automatic | :challenge
          }
  )

  (
    @typedoc nil
    @type created :: %{
            optional(:gt) => integer,
            optional(:gte) => integer,
            optional(:lt) => integer,
            optional(:lte) => integer
          }
  )

  (
    @typedoc nil
    @type custom_fields :: %{optional(:name) => binary, optional(:value) => binary}
  )

  (
    @typedoc nil
    @type customer_balance :: %{
            optional(:bank_transfer) => bank_transfer,
            optional(:funding_type) => binary
          }
  )

  (
    @typedoc "Details about the customer you want to invoice or overrides for an existing customer. If `automatic_tax` is enabled then one of `customer`, `customer_details`, `subscription`, or `schedule` must be set."
    @type customer_details :: %{
            optional(:address) => address | binary,
            optional(:shipping) => shipping | binary,
            optional(:tax) => tax,
            optional(:tax_exempt) => :exempt | :none | :reverse,
            optional(:tax_ids) => list(tax_ids)
          }
  )

  (
    @typedoc "The estimated range for how long shipping will take, meant to be displayable to the customer. This will appear on CheckoutSessions."
    @type delivery_estimate :: %{optional(:maximum) => maximum, optional(:minimum) => minimum}
  )

  (
    @typedoc nil
    @type discounts :: %{
            optional(:coupon) => binary,
            optional(:discount) => binary,
            optional(:promotion_code) => binary
          }
  )

  (
    @typedoc nil
    @type due_date :: %{
            optional(:gt) => integer,
            optional(:gte) => integer,
            optional(:lt) => integer,
            optional(:lte) => integer
          }
  )

  (
    @typedoc "The number of intervals the phase should last. If set, `end_date` must not be set."
    @type duration :: %{
            optional(:interval) => :day | :month | :week | :year,
            optional(:interval_count) => integer
          }
  )

  (
    @typedoc "End of the invoice item period."
    @type end_field :: %{
            optional(:timestamp) => integer,
            optional(:type) => :min_item_period_end | :phase_end | :timestamp
          }
  )

  (
    @typedoc "Configuration for eu_bank_transfer funding type."
    @type eu_bank_transfer :: %{optional(:country) => binary}
  )

  (
    @typedoc "Provide filters for the linked accounts that the customer can select for the payment method."
    @type filters :: %{optional(:account_subcategories) => list(:checking | :savings)}
  )

  (
    @typedoc "Additional fields for Financial Connections Session creation"
    @type financial_connections :: %{
            optional(:filters) => filters,
            optional(:permissions) =>
              list(:balances | :ownership | :payment_method | :transactions),
            optional(:prefetch) => list(:balances | :ownership | :transactions)
          }
  )

  (
    @typedoc "Describes a fixed amount to charge for shipping. Must be present if type is `fixed_amount`."
    @type fixed_amount :: %{
            optional(:amount) => integer,
            optional(:currency) => binary,
            optional(:currency_options) => map()
          }
  )

  (
    @typedoc "Configure behavior for flexible billing mode."
    @type flexible :: %{optional(:proration_discounts) => :included | :itemized}
  )

  (
    @typedoc "Revise an existing invoice. The new invoice will be created in `status=draft`. See the [revision documentation](https://stripe.com/docs/invoicing/invoice-revisions) for more details."
    @type from_invoice :: %{optional(:action) => :revision, optional(:invoice) => binary}
  )

  (
    @typedoc "Installment configuration for payments attempted on this invoice.\n\nFor more information, see the [installments integration guide](https://stripe.com/docs/payments/installments)."
    @type installments :: %{optional(:enabled) => boolean, optional(:plan) => plan | binary}
  )

  (
    @typedoc nil
    @type invoice_items :: %{
            optional(:amount) => integer,
            optional(:currency) => binary,
            optional(:description) => binary,
            optional(:discountable) => boolean,
            optional(:discounts) => list(discounts) | binary,
            optional(:invoiceitem) => binary,
            optional(:metadata) => %{optional(binary) => binary} | binary,
            optional(:period) => period,
            optional(:price) => binary,
            optional(:price_data) => price_data,
            optional(:quantity) => integer,
            optional(:tax_behavior) => :exclusive | :inclusive | :unspecified,
            optional(:tax_code) => binary | binary,
            optional(:tax_rates) => list(binary) | binary,
            optional(:unit_amount) => integer,
            optional(:unit_amount_decimal) => binary
          }
  )

  (
    @typedoc "All invoices will be billed using the specified settings."
    @type invoice_settings :: %{
            optional(:account_tax_ids) => list(binary) | binary,
            optional(:days_until_due) => integer,
            optional(:issuer) => issuer
          }
  )

  (
    @typedoc "The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account."
    @type issuer :: %{optional(:account) => binary, optional(:type) => :account | :self}
  )

  (
    @typedoc nil
    @type items :: %{
            optional(:billing_thresholds) => billing_thresholds | binary,
            optional(:clear_usage) => boolean,
            optional(:deleted) => boolean,
            optional(:discounts) => list(discounts) | binary,
            optional(:id) => binary,
            optional(:metadata) => %{optional(binary) => binary} | binary,
            optional(:plan) => binary,
            optional(:price) => binary,
            optional(:price_data) => price_data,
            optional(:quantity) => integer,
            optional(:tax_rates) => list(binary) | binary
          }
  )

  (
    @typedoc "The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account."
    @type liability :: %{optional(:account) => binary, optional(:type) => :account | :self}
  )

  (
    @typedoc nil
    @type lines :: %{
            optional(:amount) => integer,
            optional(:description) => binary,
            optional(:discountable) => boolean,
            optional(:discounts) => list(discounts) | binary,
            optional(:invoice_item) => binary,
            optional(:metadata) => %{optional(binary) => binary} | binary,
            optional(:period) => period,
            optional(:price_data) => price_data,
            optional(:pricing) => pricing,
            optional(:quantity) => integer,
            optional(:tax_amounts) => list(tax_amounts) | binary,
            optional(:tax_rates) => list(binary) | binary
          }
  )

  (
    @typedoc "Additional fields for Mandate creation"
    @type mandate_options :: %{optional(:transaction_type) => :business | :personal}
  )

  (
    @typedoc "The upper bound of the estimated range. If empty, represents no upper bound i.e., infinite."
    @type maximum :: %{
            optional(:unit) => :business_day | :day | :hour | :month | :week,
            optional(:value) => integer
          }
  )

  (
    @typedoc "The lower bound of the estimated range. If empty, represents no lower bound."
    @type minimum :: %{
            optional(:unit) => :business_day | :day | :hour | :month | :week,
            optional(:value) => integer
          }
  )

  (
    @typedoc "Payment-method-specific configuration to provide to the invoice’s PaymentIntent."
    @type payment_method_options :: %{
            optional(:acss_debit) => acss_debit | binary,
            optional(:bancontact) => bancontact | binary,
            optional(:card) => card | binary,
            optional(:customer_balance) => customer_balance | binary,
            optional(:konbini) => map() | binary,
            optional(:sepa_debit) => map() | binary,
            optional(:us_bank_account) => us_bank_account | binary
          }
  )

  (
    @typedoc "Configuration settings for the PaymentIntent that is generated when the invoice is finalized."
    @type payment_settings :: %{
            optional(:default_mandate) => binary | binary,
            optional(:payment_method_options) => payment_method_options,
            optional(:payment_method_types) =>
              list(
                :ach_credit_transfer
                | :ach_debit
                | :acss_debit
                | :affirm
                | :amazon_pay
                | :au_becs_debit
                | :bacs_debit
                | :bancontact
                | :boleto
                | :card
                | :cashapp
                | :crypto
                | :custom
                | :customer_balance
                | :eps
                | :fpx
                | :giropay
                | :grabpay
                | :ideal
                | :jp_credit_transfer
                | :kakao_pay
                | :klarna
                | :konbini
                | :kr_card
                | :link
                | :multibanco
                | :naver_pay
                | :nz_bank_account
                | :p24
                | :payco
                | :paynow
                | :paypal
                | :promptpay
                | :revolut_pay
                | :sepa_credit_transfer
                | :sepa_debit
                | :sofort
                | :swish
                | :us_bank_account
                | :wechat_pay
              )
              | binary
          }
  )

  (
    @typedoc "Invoice pdf rendering options"
    @type pdf :: %{optional(:page_size) => :a4 | :auto | :letter}
  )

  (
    @typedoc "The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://stripe.com/docs/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://stripe.com/docs/revenue-recognition/methodology/subscriptions-and-invoicing) for details."
    @type period :: %{optional(:end) => integer, optional(:start) => integer}
  )

  (
    @typedoc nil
    @type phases :: %{
            optional(:add_invoice_items) => list(add_invoice_items),
            optional(:application_fee_percent) => number,
            optional(:automatic_tax) => automatic_tax,
            optional(:billing_cycle_anchor) => :automatic | :phase_start,
            optional(:billing_thresholds) => billing_thresholds | binary,
            optional(:collection_method) => :charge_automatically | :send_invoice,
            optional(:currency) => binary,
            optional(:default_payment_method) => binary,
            optional(:default_tax_rates) => list(binary) | binary,
            optional(:description) => binary | binary,
            optional(:discounts) => list(discounts) | binary,
            optional(:duration) => duration,
            optional(:end_date) => integer | :now,
            optional(:invoice_settings) => invoice_settings,
            optional(:items) => list(items),
            optional(:metadata) => %{optional(binary) => binary},
            optional(:on_behalf_of) => binary,
            optional(:proration_behavior) => :always_invoice | :create_prorations | :none,
            optional(:start_date) => integer | :now,
            optional(:transfer_data) => transfer_data,
            optional(:trial) => boolean,
            optional(:trial_end) => integer | :now
          }
  )

  (
    @typedoc nil
    @type plan :: %{
            optional(:count) => integer,
            optional(:interval) => :month,
            optional(:type) => :bonus | :fixed_count | :revolving
          }
  )

  (
    @typedoc "Data used to generate a new [Price](https://stripe.com/docs/api/prices) object inline."
    @type price_data :: %{
            optional(:currency) => binary,
            optional(:product) => binary,
            optional(:product_data) => product_data,
            optional(:tax_behavior) => :exclusive | :inclusive | :unspecified,
            optional(:unit_amount) => integer,
            optional(:unit_amount_decimal) => binary
          }
  )

  (
    @typedoc "The pricing information for the invoice item."
    @type pricing :: %{optional(:price) => binary}
  )

  (
    @typedoc "Data used to generate a new [Product](https://docs.stripe.com/api/products) object inline. One of `product` or `product_data` is required."
    @type product_data :: %{
            optional(:description) => binary,
            optional(:images) => list(binary),
            optional(:metadata) => %{optional(binary) => binary},
            optional(:name) => binary,
            optional(:tax_code) => binary,
            optional(:unit_label) => binary
          }
  )

  (
    @typedoc "The recurring components of a price such as `interval` and `interval_count`."
    @type recurring :: %{
            optional(:interval) => :day | :month | :week | :year,
            optional(:interval_count) => integer
          }
  )

  (
    @typedoc "The rendering-related settings that control how the invoice is displayed on customer-facing surfaces such as PDF and Hosted Invoice Page."
    @type rendering :: %{
            optional(:amount_tax_display) => :exclude_tax | :include_inclusive_tax,
            optional(:pdf) => pdf,
            optional(:template) => binary,
            optional(:template_version) => integer | binary
          }
  )

  (
    @typedoc "The schedule creation or modification params to apply as a preview. Cannot be used with `subscription` or `subscription_` prefixed fields."
    @type schedule_details :: %{
            optional(:billing_mode) => billing_mode,
            optional(:end_behavior) => :cancel | :release,
            optional(:phases) => list(phases),
            optional(:proration_behavior) => :always_invoice | :create_prorations | :none
          }
  )

  (
    @typedoc nil
    @type shipping :: %{
            optional(:address) => address,
            optional(:name) => binary,
            optional(:phone) => binary
          }
  )

  (
    @typedoc "Settings for the cost of shipping for this invoice."
    @type shipping_cost :: %{
            optional(:shipping_rate) => binary,
            optional(:shipping_rate_data) => shipping_rate_data
          }
  )

  (
    @typedoc "Shipping details for the invoice. The Invoice PDF will use the `shipping_details` value if it is set, otherwise the PDF will render the shipping address from the customer."
    @type shipping_details :: %{
            optional(:address) => address,
            optional(:name) => binary,
            optional(:phone) => binary | binary
          }
  )

  (
    @typedoc "Parameters to create a new ad-hoc shipping rate for this order."
    @type shipping_rate_data :: %{
            optional(:delivery_estimate) => delivery_estimate,
            optional(:display_name) => binary,
            optional(:fixed_amount) => fixed_amount,
            optional(:metadata) => %{optional(binary) => binary},
            optional(:tax_behavior) => :exclusive | :inclusive | :unspecified,
            optional(:tax_code) => binary,
            optional(:type) => :fixed_amount
          }
  )

  (
    @typedoc "Start of the invoice item period."
    @type start :: %{
            optional(:timestamp) => integer,
            optional(:type) => :max_item_period_start | :phase_start | :timestamp
          }
  )

  (
    @typedoc "The subscription creation or modification params to apply as a preview. Cannot be used with `schedule` or `schedule_details` fields."
    @type subscription_details :: %{
            optional(:billing_cycle_anchor) => (:now | :unchanged) | integer,
            optional(:billing_mode) => billing_mode,
            optional(:cancel_at) => integer | binary | :max_period_end | :min_period_end,
            optional(:cancel_at_period_end) => boolean,
            optional(:cancel_now) => boolean,
            optional(:default_tax_rates) => list(binary) | binary,
            optional(:items) => list(items),
            optional(:proration_behavior) => :always_invoice | :create_prorations | :none,
            optional(:proration_date) => integer,
            optional(:resume_at) => :now,
            optional(:start_date) => integer,
            optional(:trial_end) => :now | integer
          }
  )

  (
    @typedoc "Tax details about the customer."
    @type tax :: %{optional(:ip_address) => binary | binary}
  )

  (
    @typedoc nil
    @type tax_amounts :: %{
            optional(:amount) => integer,
            optional(:tax_rate_data) => tax_rate_data,
            optional(:taxability_reason) =>
              :customer_exempt
              | :not_collecting
              | :not_subject_to_tax
              | :not_supported
              | :portion_product_exempt
              | :portion_reduced_rated
              | :portion_standard_rated
              | :product_exempt
              | :product_exempt_holiday
              | :proportionally_rated
              | :reduced_rated
              | :reverse_charge
              | :standard_rated
              | :taxable_basis_reduced
              | :zero_rated,
            optional(:taxable_amount) => integer
          }
  )

  (
    @typedoc nil
    @type tax_ids :: %{
            optional(:type) =>
              :ad_nrt
              | :ae_trn
              | :al_tin
              | :am_tin
              | :ao_tin
              | :ar_cuit
              | :au_abn
              | :au_arn
              | :aw_tin
              | :az_tin
              | :ba_tin
              | :bb_tin
              | :bd_bin
              | :bf_ifu
              | :bg_uic
              | :bh_vat
              | :bj_ifu
              | :bo_tin
              | :br_cnpj
              | :br_cpf
              | :bs_tin
              | :by_tin
              | :ca_bn
              | :ca_gst_hst
              | :ca_pst_bc
              | :ca_pst_mb
              | :ca_pst_sk
              | :ca_qst
              | :cd_nif
              | :ch_uid
              | :ch_vat
              | :cl_tin
              | :cm_niu
              | :cn_tin
              | :co_nit
              | :cr_tin
              | :cv_nif
              | :de_stn
              | :do_rcn
              | :ec_ruc
              | :eg_tin
              | :es_cif
              | :et_tin
              | :eu_oss_vat
              | :eu_vat
              | :gb_vat
              | :ge_vat
              | :gn_nif
              | :hk_br
              | :hr_oib
              | :hu_tin
              | :id_npwp
              | :il_vat
              | :in_gst
              | :is_vat
              | :jp_cn
              | :jp_rn
              | :jp_trn
              | :ke_pin
              | :kg_tin
              | :kh_tin
              | :kr_brn
              | :kz_bin
              | :la_tin
              | :li_uid
              | :li_vat
              | :ma_vat
              | :md_vat
              | :me_pib
              | :mk_vat
              | :mr_nif
              | :mx_rfc
              | :my_frp
              | :my_itn
              | :my_sst
              | :ng_tin
              | :no_vat
              | :no_voec
              | :np_pan
              | :nz_gst
              | :om_vat
              | :pe_ruc
              | :ph_tin
              | :ro_tin
              | :rs_pib
              | :ru_inn
              | :ru_kpp
              | :sa_vat
              | :sg_gst
              | :sg_uen
              | :si_tin
              | :sn_ninea
              | :sr_fin
              | :sv_nit
              | :th_vat
              | :tj_tin
              | :tr_tin
              | :tw_vat
              | :tz_vat
              | :ua_vat
              | :ug_tin
              | :us_ein
              | :uy_ruc
              | :uz_tin
              | :uz_vat
              | :ve_rif
              | :vn_tin
              | :za_vat
              | :zm_tin
              | :zw_tin,
            optional(:value) => binary
          }
  )

  (
    @typedoc "Data to find or create a TaxRate object.\n\nStripe automatically creates or reuses a TaxRate object for each tax amount. If the `tax_rate_data` exactly matches a previous value, Stripe will reuse the TaxRate object. TaxRate objects created automatically by Stripe are immediately archived, do not appear in the line item’s `tax_rates`, and cannot be directly added to invoices, payments, or line items."
    @type tax_rate_data :: %{
            optional(:country) => binary,
            optional(:description) => binary,
            optional(:display_name) => binary,
            optional(:inclusive) => boolean,
            optional(:jurisdiction) => binary,
            optional(:jurisdiction_level) =>
              :city | :country | :county | :district | :multiple | :state,
            optional(:percentage) => number,
            optional(:state) => binary,
            optional(:tax_type) =>
              :amusement_tax
              | :communications_tax
              | :gst
              | :hst
              | :igst
              | :jct
              | :lease_tax
              | :pst
              | :qst
              | :retail_delivery_fee
              | :rst
              | :sales_tax
              | :service_tax
              | :vat
          }
  )

  (
    @typedoc "If specified, the funds from the invoice will be transferred to the destination and the ID of the resulting transfer will be found on the invoice's charge."
    @type transfer_data :: %{optional(:amount) => integer, optional(:destination) => binary}
  )

  (
    @typedoc nil
    @type us_bank_account :: %{
            optional(:financial_connections) => financial_connections,
            optional(:verification_method) => :automatic | :instant | :microdeposits
          }
  )

  (
    nil

    @doc "<p>Permanently deletes a one-off invoice draft. This cannot be undone. Attempts to delete invoices that are no longer in a draft state will fail; once an invoice has been finalized or if an invoice is for a subscription, it must be <a href=\"#void_invoice\">voided</a>.</p>\n\n#### Details\n\n * Method: `delete`\n * Path: `/v1/invoices/{invoice}`\n"
    (
      @spec delete(invoice :: binary(), opts :: Keyword.t()) ::
              {:ok, Stripe.DeletedInvoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def delete(invoice, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_method(:delete)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>You can list all invoices, or list the invoices for a specific customer. The invoices are returned sorted by creation date, with the most recently created invoices appearing first.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/invoices`\n"
    (
      @spec list(
              params :: %{
                optional(:collection_method) => :charge_automatically | :send_invoice,
                optional(:created) => created | integer,
                optional(:customer) => binary,
                optional(:due_date) => due_date | integer,
                optional(:ending_before) => binary,
                optional(:expand) => list(binary),
                optional(:limit) => integer,
                optional(:starting_after) => binary,
                optional(:status) => :draft | :open | :paid | :uncollectible | :void,
                optional(:subscription) => binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.List.t(Stripe.Invoice.t())}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def list(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/invoices", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Retrieves the invoice with the given ID.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/invoices/{invoice}`\n"
    (
      @spec retrieve(
              invoice :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def retrieve(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Search for invoices you’ve previously created using Stripe’s <a href=\"/docs/search#search-query-language\">Search Query Language</a>.\nDon’t use search in read-after-write flows where strict consistency is necessary. Under normal operating\nconditions, data is searchable in less than a minute. Occasionally, propagation of new or updated data can be up\nto an hour behind during outages. Search functionality is not available to merchants in India.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/invoices/search`\n"
    (
      @spec search(
              params :: %{
                optional(:expand) => list(binary),
                optional(:limit) => integer,
                optional(:page) => binary,
                optional(:query) => binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.SearchResult.t(Stripe.Invoice.t())}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def search(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/invoices/search", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>This endpoint creates a draft invoice for a given customer. The invoice remains a draft until you <a href=\"#finalize_invoice\">finalize</a> the invoice, which allows you to <a href=\"#pay_invoice\">pay</a> or <a href=\"#send_invoice\">send</a> the invoice to your customers.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices`\n"
    (
      @spec create(
              params :: %{
                optional(:account_tax_ids) => list(binary) | binary,
                optional(:application_fee_amount) => integer,
                optional(:auto_advance) => boolean,
                optional(:automatic_tax) => automatic_tax,
                optional(:automatically_finalizes_at) => integer,
                optional(:collection_method) => :charge_automatically | :send_invoice,
                optional(:currency) => binary,
                optional(:custom_fields) => list(custom_fields) | binary,
                optional(:customer) => binary,
                optional(:days_until_due) => integer,
                optional(:default_payment_method) => binary,
                optional(:default_source) => binary,
                optional(:default_tax_rates) => list(binary),
                optional(:description) => binary,
                optional(:discounts) => list(discounts) | binary,
                optional(:due_date) => integer,
                optional(:effective_at) => integer,
                optional(:expand) => list(binary),
                optional(:footer) => binary,
                optional(:from_invoice) => from_invoice,
                optional(:issuer) => issuer,
                optional(:metadata) => %{optional(binary) => binary} | binary,
                optional(:number) => binary,
                optional(:on_behalf_of) => binary,
                optional(:payment_settings) => payment_settings,
                optional(:pending_invoice_items_behavior) => :exclude | :include,
                optional(:rendering) => rendering,
                optional(:shipping_cost) => shipping_cost,
                optional(:shipping_details) => shipping_details,
                optional(:statement_descriptor) => binary,
                optional(:subscription) => binary,
                optional(:transfer_data) => transfer_data
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def create(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/invoices", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Draft invoices are fully editable. Once an invoice is <a href=\"/docs/billing/invoices/workflow#finalized\">finalized</a>,\nmonetary values, as well as <code>collection_method</code>, become uneditable.</p>\n\n<p>If you would like to stop the Stripe Billing engine from automatically finalizing, reattempting payments on,\nsending reminders for, or <a href=\"/docs/billing/invoices/reconciliation\">automatically reconciling</a> invoices, pass\n<code>auto_advance=false</code>.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}`\n"
    (
      @spec update(
              invoice :: binary(),
              params :: %{
                optional(:account_tax_ids) => list(binary) | binary,
                optional(:application_fee_amount) => integer,
                optional(:auto_advance) => boolean,
                optional(:automatic_tax) => automatic_tax,
                optional(:automatically_finalizes_at) => integer,
                optional(:collection_method) => :charge_automatically | :send_invoice,
                optional(:custom_fields) => list(custom_fields) | binary,
                optional(:days_until_due) => integer,
                optional(:default_payment_method) => binary,
                optional(:default_source) => binary | binary,
                optional(:default_tax_rates) => list(binary) | binary,
                optional(:description) => binary,
                optional(:discounts) => list(discounts) | binary,
                optional(:due_date) => integer,
                optional(:effective_at) => integer | binary,
                optional(:expand) => list(binary),
                optional(:footer) => binary,
                optional(:issuer) => issuer,
                optional(:metadata) => %{optional(binary) => binary} | binary,
                optional(:number) => binary | binary,
                optional(:on_behalf_of) => binary | binary,
                optional(:payment_settings) => payment_settings,
                optional(:rendering) => rendering,
                optional(:shipping_cost) => shipping_cost | binary,
                optional(:shipping_details) => shipping_details | binary,
                optional(:statement_descriptor) => binary,
                optional(:transfer_data) => transfer_data | binary
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def update(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Adds multiple line items to an invoice. This is only possible when an invoice is still a draft.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/add_lines`\n"
    (
      @spec add_lines(
              invoice :: binary(),
              params :: %{
                optional(:expand) => list(binary),
                optional(:invoice_metadata) => map() | binary,
                optional(:lines) => list(lines)
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def add_lines(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/add_lines",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Attaches a PaymentIntent or an Out of Band Payment to the invoice, adding it to the list of <code>payments</code>.</p>\n\n<p>For the PaymentIntent, when the PaymentIntent’s status changes to <code>succeeded</code>, the payment is credited\nto the invoice, increasing its <code>amount_paid</code>. When the invoice is fully paid, the\ninvoice’s status becomes <code>paid</code>.</p>\n\n<p>If the PaymentIntent’s status is already <code>succeeded</code> when it’s attached, it’s\ncredited to the invoice immediately.</p>\n\n<p>See: <a href=\"/docs/invoicing/partial-payments\">Partial payments</a> to learn more.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/attach_payment`\n"
    (
      @spec attach_payment(
              invoice :: binary(),
              params :: %{
                optional(:expand) => list(binary),
                optional(:payment_intent) => binary,
                optional(:payment_record) => binary
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def attach_payment(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/attach_payment",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Stripe automatically finalizes drafts before sending and attempting payment on invoices. However, if you’d like to finalize a draft invoice manually, you can do so using this method.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/finalize`\n"
    (
      @spec finalize_invoice(
              invoice :: binary(),
              params :: %{optional(:auto_advance) => boolean, optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def finalize_invoice(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/finalize",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Marking an invoice as uncollectible is useful for keeping track of bad debts that can be written off for accounting purposes.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/mark_uncollectible`\n"
    (
      @spec mark_uncollectible(
              invoice :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def mark_uncollectible(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/mark_uncollectible",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Stripe automatically creates and then attempts to collect payment on invoices for customers on subscriptions according to your <a href=\"https://dashboard.stripe.com/account/billing/automatic\">subscriptions settings</a>. However, if you’d like to attempt payment on an invoice out of the normal collection schedule or for some other reason, you can do so.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/pay`\n"
    (
      @spec pay(
              invoice :: binary(),
              params :: %{
                optional(:expand) => list(binary),
                optional(:forgive) => boolean,
                optional(:mandate) => binary | binary,
                optional(:off_session) => boolean,
                optional(:paid_out_of_band) => boolean,
                optional(:payment_method) => binary,
                optional(:source) => binary
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def pay(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/pay",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Removes multiple line items from an invoice. This is only possible when an invoice is still a draft.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/remove_lines`\n"
    (
      @spec remove_lines(
              invoice :: binary(),
              params :: %{
                optional(:expand) => list(binary),
                optional(:invoice_metadata) => map() | binary,
                optional(:lines) => list(lines)
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def remove_lines(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/remove_lines",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Stripe will automatically send invoices to customers according to your <a href=\"https://dashboard.stripe.com/account/billing/automatic\">subscriptions settings</a>. However, if you’d like to manually send an invoice to your customer out of the normal schedule, you can do so. When sending invoices that have already been paid, there will be no reference to the payment in the email.</p>\n\n<p>Requests made in test-mode result in no emails being sent, despite sending an <code>invoice.sent</code> event.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/send`\n"
    (
      @spec send_invoice(
              invoice :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def send_invoice(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/send",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Updates multiple line items on an invoice. This is only possible when an invoice is still a draft.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/update_lines`\n"
    (
      @spec update_lines(
              invoice :: binary(),
              params :: %{
                optional(:expand) => list(binary),
                optional(:invoice_metadata) => map() | binary,
                optional(:lines) => list(lines)
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def update_lines(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/update_lines",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Mark a finalized invoice as void. This cannot be undone. Voiding an invoice is similar to <a href=\"#delete_invoice\">deletion</a>, however it only applies to finalized invoices and maintains a papertrail where the invoice can still be found.</p>\n\n<p>Consult with local regulations to determine whether and how an invoice might be amended, canceled, or voided in the jurisdiction you’re doing business in. You might need to <a href=\"#create_invoice\">issue another invoice</a> or <a href=\"#create_credit_note\">credit note</a> instead. Stripe recommends that you consult with your legal counsel for advice specific to your business.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/{invoice}/void`\n"
    (
      @spec void_invoice(
              invoice :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def void_invoice(invoice, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/invoices/{invoice}/void",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "invoice",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "invoice",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [invoice]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>At any time, you can preview the upcoming invoice for a subscription or subscription schedule. This will show you all the charges that are pending, including subscription renewal charges, invoice item charges, etc. It will also show you any discounts that are applicable to the invoice.</p>\n\n<p>You can also preview the effects of creating or updating a subscription or subscription schedule, including a preview of any prorations that will take place. To ensure that the actual proration is calculated exactly the same as the previewed proration, you should pass the <code>subscription_details.proration_date</code> parameter when doing the actual subscription update.</p>\n\n<p>The recommended way to get only the prorations being previewed on the invoice is to consider line items where <code>parent.subscription_item_details.proration</code> is <code>true</code>.</p>\n\n<p>Note that when you are viewing an upcoming invoice, you are simply viewing a preview – the invoice has not yet been created. As such, the upcoming invoice will not show up in invoice listing calls, and you cannot use the API to pay or edit the invoice. If you want to change the amount that your customer will be billed, you can add, remove, or update pending invoice items, or update the customer’s discount.</p>\n\n<p>Note: Currency conversion calculations use the latest exchange rates. Exchange rates may vary between the time of the preview and the time of the actual invoice creation. <a href=\"https://docs.stripe.com/currencies/conversions\">Learn more</a></p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/invoices/create_preview`\n"
    (
      @spec create_preview(
              params :: %{
                optional(:automatic_tax) => automatic_tax,
                optional(:currency) => binary,
                optional(:customer) => binary,
                optional(:customer_details) => customer_details,
                optional(:discounts) => list(discounts) | binary,
                optional(:expand) => list(binary),
                optional(:invoice_items) => list(invoice_items),
                optional(:issuer) => issuer,
                optional(:on_behalf_of) => binary | binary,
                optional(:preview_mode) => :next | :recurring,
                optional(:schedule) => binary,
                optional(:schedule_details) => schedule_details,
                optional(:subscription) => binary,
                optional(:subscription_details) => subscription_details
              },
              opts :: Keyword.t()
            ) :: {:ok, Stripe.Invoice.t()} | {:error, Stripe.ApiErrors.t()} | {:error, term()}
      def create_preview(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/invoices/create_preview", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )
end