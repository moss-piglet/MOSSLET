defmodule Stripe.Card do
  use Stripe.Entity

  @moduledoc "You can store multiple cards on a customer in order to charge the customer\nlater. You can also store multiple debit cards on a recipient in order to\ntransfer to those cards later.\n\nRelated guide: [Card payments with Sources](https://stripe.com/docs/sources/cards)"
  (
    defstruct [
      :allow_redisplay,
      :address_country,
      :dynamic_last4,
      :default_for_currency,
      :address_line1_check,
      :customer,
      :iin,
      :account,
      :last4,
      :cvc_check,
      :address_zip,
      :exp_year,
      :status,
      :regulated_status,
      :address_city,
      :description,
      :name,
      :id,
      :fingerprint,
      :issuer,
      :currency,
      :funding,
      :object,
      :tokenization_method,
      :brand,
      :address_line2,
      :country,
      :available_payout_methods,
      :exp_month,
      :address_line1,
      :address_state,
      :address_zip_check,
      :metadata,
      :networks
    ]

    @typedoc "The `card` type.\n\n  * `account` \n  * `address_city` City/District/Suburb/Town/Village.\n  * `address_country` Billing address country, if provided when creating card.\n  * `address_line1` Address line 1 (Street address/PO Box/Company name).\n  * `address_line1_check` If `address_line1` was provided, results of the check: `pass`, `fail`, `unavailable`, or `unchecked`.\n  * `address_line2` Address line 2 (Apartment/Suite/Unit/Building).\n  * `address_state` State/County/Province/Region.\n  * `address_zip` ZIP or postal code.\n  * `address_zip_check` If `address_zip` was provided, results of the check: `pass`, `fail`, `unavailable`, or `unchecked`.\n  * `allow_redisplay` This field indicates whether this payment method can be shown again to its customer in a checkout flow. Stripe products such as Checkout and Elements use this field to determine whether a payment method can be shown as a saved payment method in a checkout flow. The field defaults to “unspecified”.\n  * `available_payout_methods` A set of available payout methods for this card. Only values from this set should be passed as the `method` when creating a payout.\n  * `brand` Card brand. Can be `American Express`, `Cartes Bancaires`, `Diners Club`, `Discover`, `Eftpos Australia`, `Girocard`, `JCB`, `MasterCard`, `UnionPay`, `Visa`, or `Unknown`.\n  * `country` Two-letter ISO code representing the country of the card. You could use this attribute to get a sense of the international breakdown of cards you've collected.\n  * `currency` Three-letter [ISO code for currency](https://www.iso.org/iso-4217-currency-codes.html) in lowercase. Must be a [supported currency](https://docs.stripe.com/currencies). Only applicable on accounts (not customers or recipients). The card can be used as a transfer destination for funds in this currency. This property is only available when returned as an [External Account](/api/external_account_cards/object) where [controller.is_controller](/api/accounts/object#account_object-controller-is_controller) is `true`.\n  * `customer` The customer that this card belongs to. This attribute will not be in the card object if the card belongs to an account or recipient instead.\n  * `cvc_check` If a CVC was provided, results of the check: `pass`, `fail`, `unavailable`, or `unchecked`. A result of unchecked indicates that CVC was provided but hasn't been checked yet. Checks are typically performed when attaching a card to a Customer object, or when creating a charge. For more details, see [Check if a card is valid without a charge](https://support.stripe.com/questions/check-if-a-card-is-valid-without-a-charge).\n  * `default_for_currency` Whether this card is the default external account for its currency. This property is only available for accounts where [controller.requirement_collection](/api/accounts/object#account_object-controller-requirement_collection) is `application`, which includes Custom accounts.\n  * `description` A high-level description of the type of cards issued in this range. (For internal use only and not typically available in standard API requests.)\n  * `dynamic_last4` (For tokenized numbers only.) The last four digits of the device account number.\n  * `exp_month` Two-digit number representing the card's expiration month.\n  * `exp_year` Four-digit number representing the card's expiration year.\n  * `fingerprint` Uniquely identifies this particular card number. You can use this attribute to check whether two customers who’ve signed up with you are using the same card number, for example. For payment methods that tokenize card information (Apple Pay, Google Pay), the tokenized number might be provided instead of the underlying card number.\n\n*As of May 1, 2021, card fingerprint in India for Connect changed to allow two fingerprints for the same card---one for India and one for the rest of the world.*\n  * `funding` Card funding type. Can be `credit`, `debit`, `prepaid`, or `unknown`.\n  * `id` Unique identifier for the object.\n  * `iin` Issuer identification number of the card. (For internal use only and not typically available in standard API requests.)\n  * `issuer` The name of the card's issuing bank. (For internal use only and not typically available in standard API requests.)\n  * `last4` The last four digits of the card.\n  * `metadata` Set of [key-value pairs](https://stripe.com/docs/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.\n  * `name` Cardholder name.\n  * `networks` \n  * `object` String representing the object's type. Objects of the same type share the same value.\n  * `regulated_status` Status of a card based on the card issuer.\n  * `status` For external accounts that are cards, possible values are `new` and `errored`. If a payout fails, the status is set to `errored` and [scheduled payouts](https://stripe.com/docs/payouts#payout-schedule) are stopped until account details are updated.\n  * `tokenization_method` If the card number is tokenized, this is the method that was used. Can be `android_pay` (includes Google Pay), `apple_pay`, `masterpass`, `visa_checkout`, or null.\n"
    @type t :: %__MODULE__{
            account: (binary | Stripe.Account.t()) | nil,
            address_city: binary | nil,
            address_country: binary | nil,
            address_line1: binary | nil,
            address_line1_check: binary | nil,
            address_line2: binary | nil,
            address_state: binary | nil,
            address_zip: binary | nil,
            address_zip_check: binary | nil,
            allow_redisplay: binary | nil,
            available_payout_methods: term | nil,
            brand: binary,
            country: binary | nil,
            currency: binary | nil,
            customer: (binary | Stripe.Customer.t() | Stripe.DeletedCustomer.t()) | nil,
            cvc_check: binary | nil,
            default_for_currency: boolean | nil,
            description: binary,
            dynamic_last4: binary | nil,
            exp_month: integer,
            exp_year: integer,
            fingerprint: binary | nil,
            funding: binary,
            id: binary,
            iin: binary,
            issuer: binary,
            last4: binary,
            metadata: term | nil,
            name: binary | nil,
            networks: term,
            object: binary,
            regulated_status: binary | nil,
            status: binary | nil,
            tokenization_method: binary | nil
          }
  )

  (
    @typedoc "One or more documents that support the [Bank account ownership verification](https://support.stripe.com/questions/bank-account-ownership-verification) requirement. Must be a document associated with the bank account that displays the last 4 digits of the account number, either a statement or a check."
    @type bank_account_ownership_verification :: %{optional(:files) => list(binary)}
  )

  (
    @typedoc "Documents that may be submitted to satisfy various informational requests."
    @type documents :: %{
            optional(:bank_account_ownership_verification) => bank_account_ownership_verification
          }
  )

  (
    nil

    @doc "<p>Delete a specified external account for a given account.</p>\n\n#### Details\n\n * Method: `delete`\n * Path: `/v1/accounts/{account}/external_accounts/{id}`\n"
    (
      @spec delete(account :: binary(), id :: binary(), opts :: Keyword.t()) ::
              {:ok, Stripe.DeletedExternalAccount.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def delete(account, id, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/accounts/{account}/external_accounts/{id}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "account",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "account",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              },
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "id",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "id",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [account, id]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_method(:delete)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Updates the metadata, account holder name, account holder type of a bank account belonging to\na connected account and optionally sets it as the default for its currency. Other bank account\ndetails are not editable by design.</p>\n\n<p>You can only update bank accounts when <a href=\"/api/accounts/object#account_object-controller-requirement_collection\">account.controller.requirement_collection</a> is <code>application</code>, which includes <a href=\"/connect/custom-accounts\">Custom accounts</a>.</p>\n\n<p>You can re-enable a disabled bank account by performing an update call without providing any\narguments or changes.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/accounts/{account}/external_accounts/{id}`\n"
    (
      @spec update(
              account :: binary(),
              id :: binary(),
              params :: %{
                optional(:account_holder_name) => binary,
                optional(:account_holder_type) => :company | :individual,
                optional(:account_type) => :checking | :futsu | :savings | :toza,
                optional(:address_city) => binary,
                optional(:address_country) => binary,
                optional(:address_line1) => binary,
                optional(:address_line2) => binary,
                optional(:address_state) => binary,
                optional(:address_zip) => binary,
                optional(:default_for_currency) => boolean,
                optional(:documents) => documents,
                optional(:exp_month) => binary,
                optional(:exp_year) => binary,
                optional(:expand) => list(binary),
                optional(:metadata) => %{optional(binary) => binary} | binary,
                optional(:name) => binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.ExternalAccount.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def update(account, id, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/accounts/{account}/external_accounts/{id}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "account",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "account",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              },
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "id",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "id",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [account, id]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )
end