defmodule Stripe.Terminal.Configuration do
  use Stripe.Entity

  @moduledoc "A Configurations object represents how features should be configured for terminal readers.\nFor information about how to use it, see the [Terminal configurations documentation](https://docs.stripe.com/terminal/fleet/configurations-overview)."
  (
    defstruct [
      :bbpos_wisepad3,
      :bbpos_wisepos_e,
      :id,
      :is_account_default,
      :livemode,
      :name,
      :object,
      :offline,
      :reboot_window,
      :stripe_s700,
      :tipping,
      :verifone_p400,
      :wifi
    ]

    @typedoc "The `terminal.configuration` type.\n\n  * `bbpos_wisepad3` \n  * `bbpos_wisepos_e` \n  * `id` Unique identifier for the object.\n  * `is_account_default` Whether this Configuration is the default for your account\n  * `livemode` Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode.\n  * `name` String indicating the name of the Configuration object, set by the user\n  * `object` String representing the object's type. Objects of the same type share the same value.\n  * `offline` \n  * `reboot_window` \n  * `stripe_s700` \n  * `tipping` \n  * `verifone_p400` \n  * `wifi` \n"
    @type t :: %__MODULE__{
            bbpos_wisepad3: term,
            bbpos_wisepos_e: term,
            id: binary,
            is_account_default: boolean | nil,
            livemode: boolean,
            name: binary | nil,
            object: binary,
            offline: term,
            reboot_window: term,
            stripe_s700: term,
            tipping: term,
            verifone_p400: term,
            wifi: term
          }
  )

  (
    @typedoc "Tipping configuration for AED"
    @type aed :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for AUD"
    @type aud :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "An object containing device type specific settings for BBPOS WisePad 3 readers."
    @type bbpos_wisepad3 :: %{optional(:splashscreen) => binary | binary}
  )

  (
    @typedoc "An object containing device type specific settings for BBPOS WisePOS E readers."
    @type bbpos_wisepos_e :: %{optional(:splashscreen) => binary | binary}
  )

  (
    @typedoc "Tipping configuration for BGN"
    @type bgn :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for CAD"
    @type cad :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for CHF"
    @type chf :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for CZK"
    @type czk :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for DKK"
    @type dkk :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Credentials for a WPA-Enterprise WiFi network using the EAP-PEAP authentication method."
    @type enterprise_eap_peap :: %{
            optional(:ca_certificate_file) => binary,
            optional(:password) => binary,
            optional(:ssid) => binary,
            optional(:username) => binary
          }
  )

  (
    @typedoc "Credentials for a WPA-Enterprise WiFi network using the EAP-TLS authentication method."
    @type enterprise_eap_tls :: %{
            optional(:ca_certificate_file) => binary,
            optional(:client_certificate_file) => binary,
            optional(:private_key_file) => binary,
            optional(:private_key_file_password) => binary,
            optional(:ssid) => binary
          }
  )

  (
    @typedoc "Tipping configuration for EUR"
    @type eur :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for GBP"
    @type gbp :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for GIP"
    @type gip :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for HKD"
    @type hkd :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for HUF"
    @type huf :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for JPY"
    @type jpy :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for MXN"
    @type mxn :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for MYR"
    @type myr :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for NOK"
    @type nok :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for NZD"
    @type nzd :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc nil
    @type offline :: %{optional(:enabled) => boolean}
  )

  (
    @typedoc "Credentials for a WPA-Personal WiFi network."
    @type personal_psk :: %{optional(:password) => binary, optional(:ssid) => binary}
  )

  (
    @typedoc "Tipping configuration for PLN"
    @type pln :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Reboot time settings for readers. that support customized reboot time configuration."
    @type reboot_window :: %{optional(:end_hour) => integer, optional(:start_hour) => integer}
  )

  (
    @typedoc "Tipping configuration for RON"
    @type ron :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for SEK"
    @type sek :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "Tipping configuration for SGD"
    @type sgd :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "An object containing device type specific settings for Stripe S700 readers."
    @type stripe_s700 :: %{optional(:splashscreen) => binary | binary}
  )

  (
    @typedoc nil
    @type tipping :: %{
            optional(:aed) => aed,
            optional(:aud) => aud,
            optional(:bgn) => bgn,
            optional(:cad) => cad,
            optional(:chf) => chf,
            optional(:czk) => czk,
            optional(:dkk) => dkk,
            optional(:eur) => eur,
            optional(:gbp) => gbp,
            optional(:gip) => gip,
            optional(:hkd) => hkd,
            optional(:huf) => huf,
            optional(:jpy) => jpy,
            optional(:mxn) => mxn,
            optional(:myr) => myr,
            optional(:nok) => nok,
            optional(:nzd) => nzd,
            optional(:pln) => pln,
            optional(:ron) => ron,
            optional(:sek) => sek,
            optional(:sgd) => sgd,
            optional(:usd) => usd
          }
  )

  (
    @typedoc "Tipping configuration for USD"
    @type usd :: %{
            optional(:fixed_amounts) => list(integer),
            optional(:percentages) => list(integer),
            optional(:smart_tip_threshold) => integer
          }
  )

  (
    @typedoc "An object containing device type specific settings for Verifone P400 readers."
    @type verifone_p400 :: %{optional(:splashscreen) => binary | binary}
  )

  (
    @typedoc nil
    @type wifi :: %{
            optional(:enterprise_eap_peap) => enterprise_eap_peap,
            optional(:enterprise_eap_tls) => enterprise_eap_tls,
            optional(:personal_psk) => personal_psk,
            optional(:type) => :enterprise_eap_peap | :enterprise_eap_tls | :personal_psk
          }
  )

  (
    nil

    @doc "<p>Deletes a <code>Configuration</code> object.</p>\n\n#### Details\n\n * Method: `delete`\n * Path: `/v1/terminal/configurations/{configuration}`\n"
    (
      @spec delete(configuration :: binary(), opts :: Keyword.t()) ::
              {:ok, Stripe.DeletedTerminal.Configuration.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def delete(configuration, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/terminal/configurations/{configuration}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "configuration",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "configuration",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [configuration]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_method(:delete)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Returns a list of <code>Configuration</code> objects.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/terminal/configurations`\n"
    (
      @spec list(
              params :: %{
                optional(:ending_before) => binary,
                optional(:expand) => list(binary),
                optional(:is_account_default) => boolean,
                optional(:limit) => integer,
                optional(:starting_after) => binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.List.t(Stripe.Terminal.Configuration.t())}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def list(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/terminal/configurations", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Retrieves a <code>Configuration</code> object.</p>\n\n#### Details\n\n * Method: `get`\n * Path: `/v1/terminal/configurations/{configuration}`\n"
    (
      @spec retrieve(
              configuration :: binary(),
              params :: %{optional(:expand) => list(binary)},
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.Terminal.Configuration.t() | Stripe.DeletedTerminal.Configuration.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def retrieve(configuration, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/terminal/configurations/{configuration}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "configuration",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "configuration",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [configuration]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:get)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Creates a new <code>Configuration</code> object.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/terminal/configurations`\n"
    (
      @spec create(
              params :: %{
                optional(:bbpos_wisepad3) => bbpos_wisepad3,
                optional(:bbpos_wisepos_e) => bbpos_wisepos_e,
                optional(:expand) => list(binary),
                optional(:name) => binary,
                optional(:offline) => offline | binary,
                optional(:reboot_window) => reboot_window,
                optional(:stripe_s700) => stripe_s700,
                optional(:tipping) => tipping | binary,
                optional(:verifone_p400) => verifone_p400,
                optional(:wifi) => wifi | binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.Terminal.Configuration.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def create(params \\ %{}, opts \\ []) do
        path = Stripe.OpenApi.Path.replace_path_params("/v1/terminal/configurations", [], [])

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )

  (
    nil

    @doc "<p>Updates a new <code>Configuration</code> object.</p>\n\n#### Details\n\n * Method: `post`\n * Path: `/v1/terminal/configurations/{configuration}`\n"
    (
      @spec update(
              configuration :: binary(),
              params :: %{
                optional(:bbpos_wisepad3) => bbpos_wisepad3 | binary,
                optional(:bbpos_wisepos_e) => bbpos_wisepos_e | binary,
                optional(:expand) => list(binary),
                optional(:name) => binary,
                optional(:offline) => offline | binary,
                optional(:reboot_window) => reboot_window | binary,
                optional(:stripe_s700) => stripe_s700 | binary,
                optional(:tipping) => tipping | binary,
                optional(:verifone_p400) => verifone_p400 | binary,
                optional(:wifi) => wifi | binary
              },
              opts :: Keyword.t()
            ) ::
              {:ok, Stripe.Terminal.Configuration.t() | Stripe.DeletedTerminal.Configuration.t()}
              | {:error, Stripe.ApiErrors.t()}
              | {:error, term()}
      def update(configuration, params \\ %{}, opts \\ []) do
        path =
          Stripe.OpenApi.Path.replace_path_params(
            "/v1/terminal/configurations/{configuration}",
            [
              %{
                __struct__: OpenApiGen.Blueprint.Parameter,
                in: "path",
                name: "configuration",
                required: true,
                schema: %{
                  __struct__: OpenApiGen.Blueprint.Parameter.Schema,
                  any_of: [],
                  items: [],
                  name: "configuration",
                  properties: [],
                  title: nil,
                  type: "string"
                }
              }
            ],
            [configuration]
          )

        Stripe.Request.new_request(opts)
        |> Stripe.Request.put_endpoint(path)
        |> Stripe.Request.put_params(params)
        |> Stripe.Request.put_method(:post)
        |> Stripe.Request.make_request()
      end
    )
  )
end